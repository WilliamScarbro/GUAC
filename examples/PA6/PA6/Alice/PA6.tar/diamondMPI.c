#include "diamond.h"
#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

void mpi_exit(int val){
    MPI_Finalize();
    return exit(val);
}

void communicate(int id, int p, diamond_data* dd){

  MPI_Status status;
  
  // communicate
  if (id%2==0){
    MPI_Send(dd->shared, 2*dd->half_block, MPI_DOUBLE, (id-1+p)%p, 0, MPI_COMM_WORLD);
    MPI_Recv(dd->shared_extra, 2*dd->half_block, MPI_DOUBLE, (id+1)%p, 0, MPI_COMM_WORLD, &status);
  } else {
    MPI_Recv(dd->shared_extra, 2*dd->half_block, MPI_DOUBLE, (id+1)%p, 0, MPI_COMM_WORLD, &status);
    MPI_Send(dd->shared, 2*dd->half_block, MPI_DOUBLE, (id-1+p)%p, 0, MPI_COMM_WORLD);
  }
    
  // fix pointers
  double* temp = dd->shared;
  dd->shared=dd->shared_extra;
  dd->shared_extra=temp;
  dd->shared0=dd->shared;
  dd->shared1=dd->shared+dd->half_block;

  //MPI_Barrier(MPI_COMM_WORLD);

}


void check_result(int n, int m, int p, double* result){
  double* cur=(double* )malloc(sizeof(double)*n);
  double* prev=(double* )malloc(sizeof(double)*n);
 
  for (int i=0; i<n; i++){
    cur[i]=i;
  }
  for (int t=0; t<m; t++){
    double* temp;
    temp=prev;
    prev=cur;
    cur=temp;
    cur[0]=(prev[0]+prev[1])/3;
    cur[n-1]=(prev[n-2]+prev[n-1])/3;
    for (int i=1; i<n-1; i++){
      cur[i]=(prev[i-1]+prev[i]+prev[i+1])/3;
    }
    //print_double_arr(cur,n);
    //printf("\n");
    
  }
  printf("correct: ");
  print_double_arr(cur,n);
  printf("\n");
  
  for (int i=0; i<n; i++){
    if (cur[i]!=result[i])
      printf("Error: incorrect result\n");
  }
  free(cur);
  free(prev);
}

void diamond_stencil(int n, int m, int p, int id){
  if (n%(2*p)!=0){
    printf("Error: 2*p does not divide n\n");
    mpi_exit(1);
  }
  if (m%(n/p)!=0){
    printf("Error: block_size (n/p) does not divide m\n");
    mpi_exit(1);
  }

  int block_size=n/p;
  int half_block=block_size/2;
  int iters=2*m/block_size-1;
  
  diamond_data dd;

  diamond_data dd_temp;
  
  // initialize
  diamond_data_ctor(&dd,half_block);
  diamond_data_ctor(&dd_temp,half_block);
  
  // first row
  top_half_diamond(id,&dd);

  // intermidiate rows
  for (int t=0; t<iters; t++){
    //printf("iteration %d\n",t);

    //printf("Befor communicate\n");
    //print_diamond_data(dd);
    communicate(id,p,&dd);
    //printf("after communicate\n");
    //print_diamond_data(dd);
    
    
    
    if (half_block*(2*id+t+2)%n==0){
    	vertical_split_diamond(&dd,&dd_temp);
    } else {
    	full_diamond(&dd);
    }

  }
     
  // last row
  communicate(id,p,&dd);
  double* local_result = (double *)malloc(sizeof(double)*block_size);
  bottom_half_diamond(&dd,local_result);

  
  // final result
  double *rotated_result  = (double *) malloc( sizeof(double) * n);
  MPI_Gather(local_result,block_size,MPI_DOUBLE,rotated_result,block_size,MPI_DOUBLE,0,MPI_COMM_WORLD);
  
  MPI_Barrier(MPI_COMM_WORLD); 
 
  if (id==0){
  
    double* result = (double *)malloc(sizeof(double)*n);
    int offset=block_size*((m/block_size)%p);
    for (int i=0; i<n; i++){
       result[i]=rotated_result[(i-offset+n)%n];
    }
    
    printf("Result:  ");
    print_double_arr(result,n);
    printf("\n");
    
    check_result(n,m,p,result);
    
    free(result);
  }

  // free
  free(rotated_result);
  free(local_result);
  diamond_data_dtor(dd);
  diamond_data_dtor(dd_temp);

  mpi_exit(0);
}


int main(int argc, char** argv){
  int id,p;
  
  MPI_Init( &argc, &argv );
  MPI_Comm_rank( MPI_COMM_WORLD, &id );
  MPI_Comm_size( MPI_COMM_WORLD, &p );

  if (argc<2){
    fprintf(stderr,"Error: required arguments 'n m'\n");
    mpi_exit(1);
  }
  int n,m;
  if ((sscanf (argv[1], "%d", &n) < 1) ||           //
      (sscanf (argv[2], "%d", &m) < 1)) {           //
    fprintf (stderr, "need int params\n");
  }
  //printf("Executing diamond_stencil n: %d m: %d p: %d id %d\n",n,m,p,id);
  
  diamond_stencil(n,m,p,id);
}
