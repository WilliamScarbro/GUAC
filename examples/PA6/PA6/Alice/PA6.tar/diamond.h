#ifndef DIAMDOND_H
#define DIADMOND_H


typedef struct diamond_data {
  double* prev0;
  double* prev1;
  double* cur;
  double* shared;
  double* shared_extra;
  double* shared0;
  double* shared1;
  int half_block;
} diamond_data;

void diamond_data_ctor(diamond_data* dd, int block_size);

void print_diamond_data(diamond_data dd);

void print_double_arr(double* arr,int len);

void diamond_data_dtor(diamond_data dd);

void full_diamond(diamond_data* dd);

void top_half_diamond(int id,diamond_data* dd);

void bottom_half_diamond(diamond_data* dd,double* result);

void vertical_split_diamond(diamond_data* dd, diamond_data* dd_temp);

#endif
