/*
 * MPI blocked 1D Jacobi
 * author: wimbo
 */

#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"
#include "timer.h"

/*
double f(int i, int n){
  if (i<n/2) return i;
  else return n-i-1;
}
*/

#define   INIT_VALUE       5000

double f(int i, int n){
  return 0.0;
//  return i;
}

int system(const char *cmd);

int main(int argc, char **argv) {
  int        id, p, i, j, k, n, t, m, v, vp;
  double     startwtime, endwtime;
  float      time;
  MPI_Status status;	/* return status for receive */
  double     *buf, *prev, *cur, *temp;


  
  MPI_Init( &argc, &argv );
  MPI_Comm_rank( MPI_COMM_WORLD, &id );
  MPI_Comm_size( MPI_COMM_WORLD, &p );
  if (argc < 4) {
    fprintf (stderr, "need problem size, #iterations and buffer size\n");
    goto EXIT;
  }
  if ((sscanf (argv[1], "%d", &n) < 1) ||           //
      (sscanf (argv[2], "%d", &m) < 1) ||           //
      (sscanf (argv[3], "%d", &k) < 1)) {           //
    fprintf (stderr, "need int params\n");
    goto EXIT;
  }

  // system("hostname");
  
  // SIMPLIFYING ASSUMPTION n%p == 0
  if (n%p != 0) {
    fprintf (stderr, "problem size (n) must be a multiple of p\n");
    goto EXIT;
  }

  if (k < 1) {
    fprintf (stderr, "buffer size (k) must be > 0\n");
    goto EXIT;
  }

  if (argc > 4) {
      v=1; 
      sscanf (argv[4], "%d", &vp); 
  } else v=0;  /* are we in verbose mode? vp = reporting process*/
 
  int block_size = (n/p+2*k);
  // Memory allocation for data array.
  prev  = (double *) malloc( sizeof(double) * block_size);
  cur   = (double *) malloc( sizeof(double) * block_size);
  buf   = (double *) malloc( sizeof(double) * k);

  if ( prev == NULL || cur == NULL || buf == NULL ) {
     printf("[ERROR] : Failed to allocate memory.\n");
     goto EXIT;
  }

  t = 0;
  if(p==1){
//		printf("T: %d, N: %d\n", m, n);
     for(i=0;i<n;i++)  {
			prev[i]=i;
			//prev[i] = f(i,n);
		 }
	// set to 
	//cur[0] = INIT_VALUE; cur[n-1] = INIT_VALUE;
    //prev[0] = INIT_VALUE; prev[n-1] = INIT_VALUE;
	//     cur[0] = f(0,n); cur[n-1] = f(n-1,n);
	//     prev[0] = f(0,n); prev[n-1] = f(n-1,n);

	// Initialization
    for ( i=0 ; i < n ; i++ ) {
         prev[i] = i;
    }

    cur[0]  = 0;
    cur[n-1]  = n-1;


	startwtime = MPI_Wtime();
     

     initialize_timer();
     start_timer();
 
   while ( t < m) {
      for ( i=1 ; i < n-1 ; i++ ) {
            cur[i] = (prev[i-1]+prev[i]+prev[i+1])/3;
      }
      temp = prev;
      prev = cur;
      cur  = temp;
      t++;
   }

    
//     while (t < m) {
//      for ( i=1 ; i < n-1 ; i++ ) {
//            cur[i] = (prev[i-1]+prev[i]+prev[i+1])/3;
//       }
//			 temp = prev; prev = cur;  cur  = temp; t++;
//      }

     stop_timer();
     time = elapsed_time();

     if(v){
       for(i=0;i<n;i++) printf("%f ",prev[i]);
       printf("\n");
     }
     //endwtime = MPI_Wtime();
     //time = endwtime-startwtime;


     printf("first, mid, last: %f %f %f\n",prev[0], prev[n/2-1], prev[n-1]);
     
     printf("Data size : %d  , #iterations : %d , time : %lf sec\n", n, t, time);
     //printf("Sequential process complete, time: %f\n", time);
     goto EXIT;     
  }

  // printf("p %d at initial barrier\n", id);  
   MPI_Barrier(MPI_COMM_WORLD);
  // printf("p %d passed initial barrier\n", id);
   
   if(id == 0) {
     // Initialization
     for(i=0;i<k;i++)  {prev[i]=0;prev[n/p+k+i]=0;}
     for(i=0;i<n/p;i++)  prev[i+k] = i;
     cur[k] = prev[k]; 
     if(v && vp==id) {
       printf("Init p %d:\n", id);
       for(i=0;i<n/p;i++) printf("%f ",prev[i+k]);
       printf("\n");
     }

     //startwtime = MPI_Wtime();
     initialize_timer();
     start_timer();

     while (t < m) {
       // exchange k values with 1
       // fill buff with prev n/p-k .. n/p-1
       for(i=0;i<k;i++)
				 buf[i]= prev[n/p+i];
       MPI_Send(buf, k, MPI_DOUBLE, 1, t, MPI_COMM_WORLD);  
       if(v&&vp==id) printf("==========> 0 sent message %d  to  1\n", t);

       MPI_Recv(buf, k, MPI_DOUBLE, 1, t, MPI_COMM_WORLD, &status);
       if(v&&vp==id) printf("==========> 0 rcvd message %d from 1\n", t);

       // fill prev n/p .. n/p+k-1 with buf
       for(i=0;i<k;i++)
				 prev[n/p+k+i] = buf[i];

       if(v&&vp==id){
				printf("Prev p 0 t:%d  \n", t);
        for(i=0;i<n/p+2*k;i++) printf("%f ",prev[i]);
					printf("\n");
       }

       for (j=0;j<k;j++) {
         for ( i=k+1 ; i < n/p+2*k-j-1 ; i++ ) {
            cur[i] = (prev[i-1]+prev[i]+prev[i+1])/3;
         }
        temp = prev; prev = cur; cur  = temp;
       } 
       t+=k;
     }
     if(v&&vp==id){
       printf("Final p:%d\n", id);
         for(i=0;i<n/p;i++) printf("%f ",prev[i+k]);
         printf("\n");
     }
     MPI_Barrier(MPI_COMM_WORLD); 
     //endwtime = MPI_Wtime();
     //time = endwtime-startwtime;
     //stop_timer();
     //time = elapsed_time();

     //printf("proc 0 complete, time: %f\n", time);
   } else if(id == p-1) {
     // Initialization
     for(i=0;i<k;i++)  {prev[i]=0;prev[n/p+k+i]=0;}
     for(i=0;i<n/p;i++)  prev[i+k] = id*(n/p)+i;
     cur[n/p+k-1] = n-1;

     if(v && vp==id) {
       printf("Init p %d:\n", id);
       for(i=0;i<n/p;i++) printf("%f ",prev[i+k]);
       printf("\n");
     }

     while (t < m) {
       // exchange k values with id-1
       MPI_Recv(buf, k, MPI_DOUBLE, id-1, t, MPI_COMM_WORLD, &status);
       if(v&&vp==id) printf("==========> %d rcvd message %d from %d\n", id, t, id-1);
       // fill prev 0 .. k-1 with buf
       for(i=0;i<k;i++)
				 prev[i] = buf[i];

       // fill buf with prev k .. 2k-1
       for(i=0;i<k;i++)
				 buf[i]= prev[k+i];
       MPI_Send(buf, k, MPI_DOUBLE, id-1, t, MPI_COMM_WORLD);  
       if(v&&vp==id) printf("==========> %d sent message %d  to  %d\n", id, t, id-1);

       if(v&&vp==id){
        printf("Prev p %d t:%d  \n", id, t);
        for(i=0;i<n/p+2*k;i++) printf("%f ",prev[i]);
        printf("\n");
       }

       for (j=0;j<k;j++) {
         for ( i=j+1 ; i < n/p+k-1 ; i++ ) {
            cur[i] = (prev[i-1]+prev[i]+prev[i+1])/3;
         }
        temp = prev; prev = cur; cur  = temp;
       } 
       t+=k;
     }
     if(v&&vp==id){
       printf("Final p %d:\n", id);
         for(i=0;i<n/p;i++) printf("%f ",prev[i+k]);
         printf("\n");
     }
     MPI_Barrier(MPI_COMM_WORLD); 
   } else {
     // Initialization
     for(i=0;i<k;i++)  {prev[i]=0;prev[n/p+k+i]=0;}
     for(i=0;i<n/p;i++)  prev[i+k] = id*(n/p)+i;
     //cur[n/p+k-1] = f(n-1,n);  // do I need this??

     if(v && vp==id) {
       printf("Init p %d:\n", id);
       for(i=0;i<n/p;i++) printf("%f ",prev[i+k]);
       printf("\n");
     }

     while (t < m) {
       // exchange k values with id-1
       MPI_Recv(buf, k, MPI_DOUBLE, id-1, t, MPI_COMM_WORLD, &status);
       if(v&&vp==id) printf("==========> %d received message %d from %d\n", id, t, id-1);
       // fill prev 0 .. k-1 with buf
       for(i=0;i<k;i++)
				 prev[i] = buf[i];
       // fill buf with prev k .. 2k-1
       for(i=0;i<k;i++)
				 buf[i]= prev[k+i];
       MPI_Send(buf, k, MPI_DOUBLE, id-1, t, MPI_COMM_WORLD);  
       if(v&&vp==id) printf("==========> %d sent message %d  to  %d\n", id, t, id-1);



       // exchange k values with id+1
       // fill buff with prev n/p-k .. n/p-1
       for(i=0;i<k;i++)
         buf[i]= prev[n/p+i];
       MPI_Send(buf, k, MPI_DOUBLE, id+1, t, MPI_COMM_WORLD);  
       if(v&&vp==id) printf("==========> %d sent message %d  to  %d\n", id, t, id+1);


       MPI_Recv(buf, k, MPI_DOUBLE, id+1, t, MPI_COMM_WORLD, &status);
       if(v&&vp==id) printf("==========> %d rcvd message %d from %d\n", id, t, id+1);
       // fill prev n/p .. n/p+k-1 with buf
       for(i=0;i<k;i++)
				 prev[n/p+k+i] = buf[i];

       if(v&&vp==id){
        printf("Prev p %d t:%d  \n", id, t);
        for(i=0;i<n/p+2*k;i++) printf("%f ",prev[i]);
        printf("\n");
       }


       for (j=0;j<k;j++) {
         for ( i=j+1 ; i < n/p+2*k-j-1 ; i++ ) {
            cur[i] = (prev[i-1]+prev[i]+prev[i+1])/3;
         }
        temp = prev; prev = cur; cur  = temp;
       } 
       t+=k;
     }
     if(v&&vp==id){
       printf("Final p:%d\n", id);
         for(i=0;i<n/p;i++) printf("%f ",prev[i+k]);
         printf("\n");
     }
     
     MPI_Barrier(MPI_COMM_WORLD); 
   }
     
	 
  double *complete  = (double *) malloc( sizeof(double) * n);
	MPI_Gather(prev+k,n/p,MPI_DOUBLE,complete,n/p,MPI_DOUBLE,0,MPI_COMM_WORLD);

	 MPI_Barrier(MPI_COMM_WORLD); 
	if (id==0) {
 		if(v&&vp==id){
			for (i=0; i<n; i++) {
				printf("%f\n", complete[i]);
			}
		}

	
     stop_timer();
     time = elapsed_time();

     printf("first, mid, last: %f %f %f\n",complete[0], complete[n/2-1], complete[n-1]);
		 printf("Data size : %d  , #iterations : %d , time : %lf sec\n", n, t, time);
	}
EXIT:
    MPI_Finalize();
    return 0;
}

