
#include "diamond.h"
#include <stdlib.h>
#include <stdio.h>

/*
       _ shared0
      |  _ shared1
      | |
  . ./_/_/. .
  ./_/_/_ _ .
 /_/_/_ _ _ _
  . _ _ _ _ .
  . . _ _ . .
  
      _ prev0
     |  _ prev1
     | |
 . .\_\_\. .
 . _ _\_\_\.
 _ _ _ _\_\_\
 . _ _ _ _ .
 . . _ _ . .
*/



void diamond_data_ctor(diamond_data* dd, int half_block){
  dd->prev0 = (double *)malloc(sizeof(double)*(half_block+1));
  dd->prev1 = (double *)malloc(sizeof(double)*(half_block+1));
  dd->cur = (double *)malloc(sizeof(double)*(half_block+1));
  dd->shared = (double *)malloc(sizeof(double)*2*half_block);
  dd->shared_extra = (double *)malloc(sizeof(double)*2*half_block);

  if ( dd->prev0 == NULL || dd->prev1 == NULL || dd->cur == NULL || dd->shared == NULL || dd->shared_extra == NULL ) {
     printf("[ERROR] : Failed to allocate memory.\n");
     exit(1);
  }
  dd->shared0=dd->shared;
  dd->shared1=dd->shared+half_block;
  dd->half_block=half_block;

  // for easy debugging
  for (int i=0; i<half_block; i++){
    dd->prev0[i]=-1;
    dd->prev1[i]=-1;
    dd->shared0[i]=-1;
    dd->shared1[i]=-1;
  }
  dd->prev0[half_block]=-1;
  dd->prev0[half_block]=-1;

}

void diamond_data_dtor(diamond_data dd){
  free(dd.prev0);
  //free(dd.prev1);
  //free(dd.cur);
  //free(dd.shared);
  //free(dd.shared_extra);
}

void print_double_arr(double* arr,int len){
  for (int i=0; i<len; i++)
    printf("%0.3f ",arr[i]);
}

void print_diamond_data(diamond_data dd){
  printf("Data\n");
  printf("  prev0: ");
  print_double_arr(dd.prev0,dd.half_block+1); // doesn't print last element (not important)
  printf("  prev1: ");
  print_double_arr(dd.prev1,dd.half_block+1);
  printf("  cur: ");
  print_double_arr(dd.cur,dd.half_block+1); // ditto
  printf("  shared0: ");
  print_double_arr(dd.shared0,dd.half_block);
  printf("  shared1: ");
  print_double_arr(dd.shared1,dd.half_block);
  printf("\n");
}
  
// utility functions

void stencil0(int j,diamond_data dd){
  double val=(dd.prev0[j]+dd.prev1[j]+dd.cur[j+1])/3;
  //printf("stencil0 %d : %0.3f + %0.3f + %0.3f = %0.3f\n",j, dd.prev0[j],dd.prev1[j],dd.cur[j+1],val);
  dd.cur[j]=val;
}

void stencil1(int j,diamond_data dd){
  double val=(dd.prev0[j]+dd.prev1[j+1]+dd.cur[j+1])/3;
  //printf("stencil1 %d : %0.3f + %0.3f + %0.3f = %0.3f\n",j, dd.prev0[j],dd.prev1[j+1],dd.cur[j+1],val);
  dd.cur[j]=val;
}

void rotate_diamond_cur(diamond_data* dd){
  double* temp;
  temp=dd->prev0;
  dd->prev0=dd->prev1;
  dd->prev1=dd->cur;
  dd->cur=temp;
}

  
// interface functions

void full_diamond(diamond_data* dd){
  //printf("Diamond\n");
  int i,j;
  for (i=0; i<dd->half_block; i++){
    dd->cur[dd->half_block]=dd->shared0[i];
    for (j=dd->half_block-1; j>=0; j--){
      stencil0(j,*dd);
    }
    dd->shared0[i]=dd->cur[0];
    rotate_diamond_cur(dd);

    dd->cur[dd->half_block]=dd->shared1[i];
    for (j=dd->half_block-1; j>=0; j--){
      stencil1(j,*dd);
    }
    dd->shared1[i]=dd->cur[0];
    rotate_diamond_cur(dd);
  }
  //print_diamond_data(*dd);
}

void top_half_diamond(int id,diamond_data* dd){
  //printf("Top Half Diamond\n");
  int i,j;
  for (i=0; i<dd->half_block; i++){
    dd->cur[i]=(2*dd->half_block*id)+2*i; //changed
    for (j=i-1; j>=0; j--){ // changed
      stencil0(j,*dd);
    }
    dd->shared0[i]=dd->cur[0];
    rotate_diamond_cur(dd);

    dd->cur[i]=(2*dd->half_block*id)+2*i+1; // changed
    for (j=i-1; j>=0; j--){ // changed
      stencil1(j,*dd);
    }
    dd->shared1[i]=dd->cur[0];
    rotate_diamond_cur(dd);
  }
  //print_diamond_data(*dd);
}

void bottom_half_diamond(diamond_data* dd,double* result){
  //printf("Bottom Half Diamond\n");
  int i,j;
  for (i=0; i<dd->half_block; i++){
    dd->cur[dd->half_block]=dd->shared0[i];
    for (j=dd->half_block-1; j>=i; j--){ // changed
      stencil0(j,*dd);
    }
    result[2*i]=dd->cur[i]; // changed
    rotate_diamond_cur(dd);

    dd->cur[dd->half_block]=dd->shared1[i];
    for (j=dd->half_block-1; j>=i; j--){ // changed
      stencil1(j,*dd);
    }
    result[2*i+1]=dd->cur[i]; // changed
    rotate_diamond_cur(dd);
  }
  
  //print_diamond_data(*dd);
}

void left_half_diamond(diamond_data* dd){
  //printf("Left Half Diamond\n");
  int i,j;
  for (i=0; i<dd->half_block; i++){
    dd->cur[dd->half_block-i]=0; // changed
    for (j=dd->half_block-i-1; j>=0; j--){ // changed 
      stencil0(j,*dd);
    }
    dd->shared0[i]=dd->cur[0];
    rotate_diamond_cur(dd);
    
    dd->cur[dd->half_block-i-1]=0; // changed
    for (j=dd->half_block-i-2; j>=0; j--){ // changed
      stencil1(j,*dd);
    }
    dd->shared1[i]=dd->cur[0];
    rotate_diamond_cur(dd);
  }
  //print_diamond_data(*dd);
}

void right_half_diamond(diamond_data* dd){
  //printf("Right Half Diamond\n");
  int i,j;
  for (i=0; i<dd->half_block; i++){
    dd->cur[dd->half_block]=dd->shared0[i];
    dd->prev0[dd->half_block-i]=0; // added
    for (j=dd->half_block-1; j>=dd->half_block-i; j--){ // changed
      stencil0(j,*dd);
    }
    // removed
    rotate_diamond_cur(dd); 

    dd->cur[dd->half_block]=dd->shared1[i];
    dd->prev0[dd->half_block-i-1]=0; // added
    for (j=dd->half_block-1; j>=dd->half_block-i-1; j--){ // changed
      stencil1(j,*dd);
    }
    // removed
    rotate_diamond_cur(dd);
  }
  dd->prev0[0]=0; // added

  //print_diamond_data(*dd);
}

void vertical_split_diamond(diamond_data* dd, diamond_data* dd_temp){
  //printf("Vertical Split Diamond\n");

  // swap prev values
  double* prev0_save=dd_temp->prev0;
  double* prev1_save=dd_temp->prev1;
  double* cur_save=dd_temp->cur; // doesn't effect computation, but avoids memory leak
  dd_temp->prev0=dd->prev0;
  dd_temp->prev1=dd->prev1;
  dd_temp->cur=dd->cur;
  dd->prev0=prev0_save;
  dd->prev1=prev1_save;
  dd->cur=cur_save;

  left_half_diamond(dd_temp); // gets new shared values, trashed prev

  right_half_diamond(dd); // gets new prev values, trashes shared

  // swap shared values
  double* shared_save=dd->shared;
  dd->shared=dd_temp->shared;
  dd_temp->shared=shared_save;

  // fix pointers
  dd->shared0=dd->shared;
  dd->shared1=dd->shared0+dd->half_block;
  dd_temp->shared0=dd_temp->shared;
  dd_temp->shared1=dd_temp->shared+dd_temp->half_block;

  // debug
  //printf("temp: ");
  //print_diamond_data(*dd_temp);
  //print_diamond_data(*dd);
}

